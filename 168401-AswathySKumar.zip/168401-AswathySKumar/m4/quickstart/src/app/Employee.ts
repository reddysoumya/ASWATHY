export interface Employee{
ID:number;
NAME:string;
SALARY:number;
DEPARTMENT:string;
DOJ:string;
}